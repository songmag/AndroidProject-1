package org.Factory;

public class MoneyFactory {

}
