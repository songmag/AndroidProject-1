package org.Game.MovePackage;

public interface I_MovePattern {
    void Update(ThrowObject object);
    void move(ThrowObject object);
}
//MovePattern에 따라 Update하고 Move 하는 작업을 한다.
